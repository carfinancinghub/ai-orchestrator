// Auto-generated stub
export class EscrowQueueService {
  constructor() {}
  async connect() {}
  async disconnect() {}
}
